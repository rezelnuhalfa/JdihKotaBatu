import 'package:flutter/material.dart';
import 'package:jdih_kota_batu/widgets/footer_navbar.dart';

class SearchPage extends StatefulWidget {
  const SearchPage({super.key});

  @override
  State<SearchPage> createState() => _SearchPageState();
}

class _SearchPageState extends State<SearchPage> {
  final TextEditingController keywordController = TextEditingController();
  final TextEditingController nomorController = TextEditingController();
  final TextEditingController tahunController = TextEditingController();

  String? selectedJenisDokumen;
  String? selectedBentukPeraturan;

  final List<String> jenisDokumenList = ['Peraturan', 'Keputusan', 'Instruksi'];
  final List<String> bentukPeraturanList = ['Perda', 'Perwali', 'SE'];

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: const Color(0xFFF9F9F9),
      body: SingleChildScrollView(
        child: Column(
          children: [
            Container(
              padding: const EdgeInsets.symmetric(horizontal: 20, vertical: 24),
              width: double.infinity,
              decoration: const BoxDecoration(
                color: Color(0xFF0C2D48),
                borderRadius: BorderRadius.only(
                  bottomLeft: Radius.circular(16),
                  bottomRight: Radius.circular(16),
                ),
              ),
              child: Row(
                mainAxisAlignment: MainAxisAlignment.spaceBetween,
                children: [
                  const Text(
                    'PENCARIAN\nPRODUK HUKUM',
                    style: TextStyle(
                      color: Colors.white,
                      fontSize: 20,
                      fontWeight: FontWeight.bold,
                    ),
                  ),
                  Image.asset("assets/images/logo_batu.png", width: 60),
                ],
              ),
            ),
            const SizedBox(height: 24),
            Padding(
              padding: const EdgeInsets.symmetric(horizontal: 20),
              child: Column(
                children: [
                  _buildTextField(
                      controller: keywordController, label: 'KATA KUNCI'),
                  const SizedBox(height: 12),
                  _buildDropdown(
                    value: selectedJenisDokumen,
                    hint: 'JENIS DOKUMEN',
                    items: jenisDokumenList,
                    onChanged: (value) {
                      setState(() {
                        selectedJenisDokumen = value;
                      });
                    },
                  ),
                  const SizedBox(height: 12),
                  _buildDropdown(
                    value: selectedBentukPeraturan,
                    hint: 'BENTUK PERATURAN',
                    items: bentukPeraturanList,
                    onChanged: (value) {
                      setState(() {
                        selectedBentukPeraturan = value;
                      });
                    },
                  ),
                  const SizedBox(height: 12),
                  _buildTextField(controller: nomorController, label: 'NOMOR'),
                  const SizedBox(height: 12),
                  _buildTextField(controller: tahunController, label: 'TAHUN'),
                  const SizedBox(height: 24),
                  SizedBox(
                    width: double.infinity,
                    height: 50,
                    child: ElevatedButton(
                      style: ElevatedButton.styleFrom(
                        backgroundColor: const Color(0xFFFFC107),
                        shape: RoundedRectangleBorder(
                          borderRadius: BorderRadius.circular(12),
                        ),
                      ),
                      onPressed: () {
                        // Fungsi pencarian nanti ditambahkan
                      },
                      child: const Text(
                        'CARI',
                        style: TextStyle(
                          fontSize: 18,
                          fontWeight: FontWeight.bold,
                          color: Colors.white,
                          letterSpacing: 1,
                        ),
                      ),
                    ),
                  ),
                  const SizedBox(height: 24),
                ],
              ),
            ),
          ],
        ),
      ),
      bottomNavigationBar: const FooterNavbar(currentIndex: 1),
    );
  }

  Widget _buildTextField(
      {required TextEditingController controller, required String label}) {
    return TextField(
      controller: controller,
      decoration: InputDecoration(
        labelText: label,
        labelStyle: const TextStyle(
          color: Colors.grey,
          fontWeight: FontWeight.w500,
        ),
        filled: true,
        fillColor: Colors.grey.shade200,
        border: OutlineInputBorder(
          borderRadius: BorderRadius.circular(8),
          borderSide: BorderSide.none,
        ),
      ),
    );
  }

  Widget _buildDropdown({
    required String? value,
    required String hint,
    required List<String> items,
    required void Function(String?) onChanged,
  }) {
    return DropdownButtonFormField<String>(
      value: value,
      hint: Text(hint),
      decoration: InputDecoration(
        filled: true,
        fillColor: Colors.grey.shade200,
        border: OutlineInputBorder(
          borderRadius: BorderRadius.circular(8),
          borderSide: BorderSide.none,
        ),
      ),
      items: items
          .map((item) => DropdownMenuItem(value: item, child: Text(item)))
          .toList(),
      onChanged: onChanged,
    );
  }
}
