import 'dart:convert';
import 'package:http/http.dart' as http;
import '../models/hukum_model.dart';

class HomePageController {
  // Untuk data peraturan terbaru (beranda & selengkapnya)
  Future<List<HukumModel>> fetchPeraturanTerbaru() async {
    try {
      final url = Uri.parse('https://jdih-simprokum.batukota.go.id/api/peraturan-terbaru');
      final response = await http.get(url);

      if (response.statusCode == 200) {
        final json = jsonDecode(response.body);
        final List data = json['prokum'];

        return data.map((item) => HukumModel.fromJson(item)).toList();
      } else {
        throw Exception('Gagal memuat data: ${response.statusCode}');
      }
    } catch (e) {
      throw Exception('Terjadi kesalahan: $e');
    }
  }

  // Untuk data peraturan perundangan (icon peraturan)
  Future<List<HukumModel>> fetchPeraturanPerundangUndangan() async {
    try {
      final url = Uri.parse(
        'https://jdih-simprokum.batukota.go.id/api/produk-hukum/peraturan-perundangan?page=1&per_page=20',
      );
      final response = await http.get(url);

      if (response.statusCode == 200) {
        final json = jsonDecode(response.body);
        final List data = json['data'];

        return data.map((item) => HukumModel.fromJson(item)).toList();
      } else {
        throw Exception('Gagal memuat data: ${response.statusCode}');
      }
    } catch (e) {
      throw Exception('Terjadi kesalahan: $e');
    }
  }
}
