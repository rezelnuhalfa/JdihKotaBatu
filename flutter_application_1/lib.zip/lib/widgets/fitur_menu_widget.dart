import 'package:flutter/material.dart';

class FiturMenuWidget extends StatelessWidget {
  final VoidCallback onTapPeraturan;

  const FiturMenuWidget({super.key, required this.onTapPeraturan});

  @override
  Widget build(BuildContext context) {
    return Padding(
      padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 20),
      child: Row(
        mainAxisAlignment: MainAxisAlignment.spaceAround,
        children: [
          // Peraturan - Bisa ditekan
          GestureDetector(
            onTap: onTapPeraturan,
            child: Column(
              children: [
                CircleAvatar(
                  radius: 30,
                  backgroundColor: Colors.blue.shade100,
                  child: Icon(Icons.gavel, size: 30, color: Colors.blue.shade800),
                ),
                const SizedBox(height: 8),
                const Text('Peraturan'),
              ],
            ),
          ),

          // Artikel
          Column(
            children: [
              CircleAvatar(
                radius: 30,
                backgroundColor: Colors.green.shade100,
                child: Icon(Icons.article, size: 30, color: Colors.green.shade800),
              ),
              const SizedBox(height: 8),
              const Text('Artikel'),
            ],
          ),

          // Monografi
          Column(
            children: [
              CircleAvatar(
                radius: 30,
                backgroundColor: Colors.orange.shade100,
                child: Icon(Icons.menu_book, size: 30, color: Colors.orange.shade800),
              ),
              const SizedBox(height: 8),
              const Text('Monografi'),
            ],
          ),

          // Putusan
          Column(
            children: [
              CircleAvatar(
                radius: 30,
                backgroundColor: Colors.purple.shade100,
                child: Icon(Icons.library_books, size: 30, color: Colors.purple.shade800),
              ),
              const SizedBox(height: 8),
              const Text('Putusan'),
            ],
          ),
        ],
      ),
    );
  }
}
