import 'package:flutter/material.dart';
import 'package:jdih_kota_batu/pages/homepage.dart';
import 'package:jdih_kota_batu/pages/homepage.dart';
import 'package:jdih_kota_batu/views/profile/search/search_page.dart';
import 'package:jdih_kota_batu/views/profile/search/search_page.dart';
import 'package:jdih_kota_batu/views/profile/profile_page.dart';

class FooterNavbar extends StatelessWidget {
  final int currentIndex;

  const FooterNavbar({super.key, required this.currentIndex});

  void _onItemTapped(BuildContext context, int index) {
    if (index == currentIndex) return; // Tidak pindah kalau klik halaman yang sama

    if (index == 0) {
      Navigator.pushReplacement(
        context,
        MaterialPageRoute(builder: (_) => const HomePage()),
      );
    } else if (index == 1) {
      Navigator.pushReplacement(
        context,
        MaterialPageRoute(builder: (_) => const SearchPage()),
      );
    } else if (index == 2) {
      Navigator.pushReplacement(
        context,
        MaterialPageRoute(builder: (_) => const ProfilePage()),
      );
    }
  }

  @override
  Widget build(BuildContext context) {
    return BottomNavigationBar(
      currentIndex: currentIndex,
      onTap: (index) => _onItemTapped(context, index),
      selectedItemColor: Colors.amber,
      unselectedItemColor: Colors.white,
      backgroundColor: const Color(0xff0f2e3c),
      items: const [
        BottomNavigationBarItem(icon: Icon(Icons.home), label: ''),
        BottomNavigationBarItem(icon: Icon(Icons.map), label: ''),
        BottomNavigationBarItem(icon: Icon(Icons.person), label: ''),
      ],
    );
  }
}
