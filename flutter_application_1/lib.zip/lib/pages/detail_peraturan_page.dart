import 'package:flutter/material.dart';
import 'package:url_launcher/url_launcher.dart';
import '../models/hukum_model.dart';

class DetailPeraturanPage extends StatelessWidget {
  final HukumModel hukum;

  const DetailPeraturanPage({super.key, required this.hukum});

  void _launchURL(String url) async {
    final Uri uri = Uri.parse(url);
    if (await canLaunchUrl(uri)) {
      await launchUrl(uri, mode: LaunchMode.externalApplication);
    } else {
      throw 'Tidak dapat membuka URL: $url';
    }
  }

  Widget _buildDetailItem({required IconData icon, required String title, required String value}) {
    return Padding(
      padding: const EdgeInsets.only(bottom: 12),
      child: Row(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Icon(icon, size: 20),
          const SizedBox(width: 8),
          Expanded(
            child: RichText(
              text: TextSpan(
                style: const TextStyle(fontSize: 16, color: Colors.black, fontFamily: 'Poppins'),
                children: [
                  TextSpan(text: "$title: ", style: const TextStyle(fontWeight: FontWeight.bold)),
                  TextSpan(text: value),
                ],
              ),
            ),
          ),
        ],
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text('Detail Peraturan'),
        backgroundColor: const Color.fromARGB(255, 45, 51, 65),
        foregroundColor: Colors.white,
      ),
      body: SingleChildScrollView(
        padding: const EdgeInsets.all(16.0),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Text(
              hukum.judul,
              style: const TextStyle(
                fontSize: 20,
                fontWeight: FontWeight.bold,
                fontFamily: 'Poppins',
              ),
            ),
            const SizedBox(height: 16),

            _buildDetailItem(icon: Icons.account_balance, title: "Kategori", value: hukum.kategori),
            _buildDetailItem(icon: Icons.calendar_today, title: "Tanggal Penetapan", value: hukum.tanggal),
            _buildDetailItem(icon: Icons.confirmation_number, title: "Nomor Peraturan", value: hukum.nomorPeraturan),
            _buildDetailItem(icon: Icons.date_range, title: "Tahun", value: hukum.tahun),
            _buildDetailItem(icon: Icons.place, title: "Tempat Penetapan", value: hukum.tempatPenetapan),
            _buildDetailItem(icon: Icons.gavel, title: "Bidang Hukum", value: hukum.bidangHukum),
            _buildDetailItem(icon: Icons.subject, title: "Subjek", value: hukum.subjek),
            _buildDetailItem(icon: Icons.person, title: "Pemrakarsa", value: hukum.pemrakarsa),

           
            if (hukum.lampiranDokumen != null && hukum.lampiranDokumen!.isNotEmpty)
              Padding(
                padding: const EdgeInsets.only(top: 12),
                child: ElevatedButton.icon(
                  style: ElevatedButton.styleFrom(
                    backgroundColor: Colors.blue,
                    foregroundColor: Colors.white,
                  ),
                  icon: const Icon(Icons.picture_as_pdf),
                  label: const Text("Buka Dokumen"),
                  onPressed: () => _launchURL(hukum.lampiranDokumen!),
                ),
              ),
          ],
        ),
      ),
    );
  }
}
